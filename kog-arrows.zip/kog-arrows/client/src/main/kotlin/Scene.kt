import org.w3c.dom.HTMLCanvasElement
import org.khronos.webgl.WebGLRenderingContext as GL //# GL# we need this for the constants declared ˙HUN˙ a constansok miatt kell
import kotlin.js.Date
import vision.gears.webglmath.UniformProvider
import vision.gears.webglmath.Vec1
import vision.gears.webglmath.Vec2
import vision.gears.webglmath.Vec3
import vision.gears.webglmath.Vec4
import vision.gears.webglmath.Mat4
import vision.gears.webglmath.*
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.cos
import kotlin.math.*

class Scene (
  val gl : WebGL2RenderingContext)  : UniformProvider("scene") {

  val vsTextured = Shader(gl, GL.VERTEX_SHADER, "textured-vs.glsl")
  val fsTextured = Shader(gl, GL.FRAGMENT_SHADER, "textured-fs.glsl")
  val texturedProgram = Program(gl, vsTextured, fsTextured)

  val vsShadow = Shader(gl, GL.VERTEX_SHADER, "shadow-vs.glsl")
  val fsShadow = Shader(gl, GL.FRAGMENT_SHADER, "shadow-fs.glsl")
  val shadowProgram = Program(gl, vsShadow, fsShadow)
  val shadowMatrix by Mat4( 
          1.0f ,    0.0f ,    0.0f ,   0.0f, 
          0.0f ,    0.0f,     0.0f ,   0.0f, 
          0.0f ,    0.0f ,    1.0f,    0.0f, 
          0.0f ,   0.01f ,    0.0f,    1.0f)
  
  val shadowMaterial = Material(shadowProgram)

  val vsQuad = Shader(gl, GL.VERTEX_SHADER, "quad-vs.glsl")
  val fsBackground = Shader(gl, GL.FRAGMENT_SHADER, "background-fs.glsl")
  val backgroundProgram = Program(gl, vsQuad, fsBackground)
  val envTexture = TextureCube(gl,
    "media/posx512.jpg",
    "media/negx512.jpg",
    "media/posy512.jpg",
    "media/negy512.jpg",
    "media/posz512.jpg",
    "media/negz512.jpg"
    )
  val backgroundMaterial = Material(backgroundProgram).apply{
    this["envTexture"]?.set(envTexture)
  }

  val quadGeometry = TexturedQuadGeometry(gl)

  val  groundMaterial = Material(texturedProgram).apply{
    this["colorTexture"]?.set(Texture2D(gl, "media/grass.jpeg"))
    this["envTexture"]?.set(envTexture)
  }

  val groundMesh = Mesh(groundMaterial, GroundGeometry(gl))

  val backgroundMesh = Mesh(backgroundMaterial, quadGeometry)

  val jsonLoader = JsonLoader()

  val targetMeshes = jsonLoader.loadMeshes(gl,
    "media/sphere/sphere.json",
    Material(texturedProgram).apply{
      this["colorTexture"]?.set(Texture2D(gl, "media/bullseye.jpeg"))
      this["envTexture"]?.set(envTexture)
    }
  )

  val arrowMeshes = jsonLoader.loadMeshes(gl,
    "media/sphere/sphere.json",
    Material(texturedProgram).apply{
      this["colorTexture"]?.set(Texture2D(gl, "media/ice.jpeg"))
      this["envTexture"]?.set(envTexture)
    }
  )

  val thunderboltMeshes = jsonLoader.loadMeshes(gl,
    "media/thunderbolt_body.json",
    Material(texturedProgram).apply{
      this["colorTexture"]?.set(Texture2D(gl, "media/grass.jpg"))
      this["envTexture"]?.set(envTexture)
    }
  )
  
  val slowpokeMeshes = jsonLoader.loadMeshes(gl,
    "media/slowpoke/slowpoke.json",
    Material(texturedProgram).apply{
      this["colorTexture"]?.set(
          Texture2D(gl, "media/slowpoke/YadonDh.png"))
      this["envTexture"]?.set(envTexture)
    },
    Material(texturedProgram).apply{
      this["colorTexture"]?.set(
          Texture2D(gl, "media/slowpoke/YadonEyeDh.png"))
      this["envTexture"]?.set(envTexture)
    }
  )

  // LABTODO: load geometries from the JSON file, create Meshes  

  val gameObjects = ArrayList<GameObject>()

  val arrowObjects = ArrayList<GameObject>()

  val avatar1 = GameObject(*targetMeshes).apply{
    scale.set(5f, 5f, 5f)
    mass = 5.0f
    yaw = 4.4f
    position.set(0f, 5f, 40f)
    //shadow = true
  }

  val avatar2 = GameObject(*targetMeshes).apply{
    scale.set(4f, 4f, 4f)
    mass = 5.0f
    yaw = 4.5f
    position.set(5.8f, 12f, 40f)
    //shadow = true
  }

  val avatar3 = GameObject(*targetMeshes).apply{
    scale.set(4f, 4f, 4f)
    mass = 5.0f
    yaw = 4.2f
    position.set(-5.8f, 12f, 40f)
    //shadow = true
  }

  init {
    // LABTODO: create and add game object using meshes loaded from JSON
    // gameObjects += GameObject(*slowpokeMeshes).apply{
    //   scale.set(0.1f, 0.1f, 0.1f)
    //   //position.set(0f, 0f, 2f)
    //   shadow = true
    //   yaw =  1.57f
    // }
    gameObjects += GameObject(groundMesh).apply{
      pitch = 1.58f
    }
    gameObjects += avatar1
    gameObjects += avatar2
    gameObjects += avatar3
  }

  // LABTODO: replace with 3D camera
  val camera = PerspectiveCamera(*Program.all).apply{
    position.set(0f, 1f)
    yaw = -3.3f
    update()
  }

  // val camera = OrthoCamera(*Program.all).apply{
  //   position.set(1f, 1f)
  //   windowSize.set(20f, 20f)
  // }

  fun resize(canvas : HTMLCanvasElement) {
    gl.viewport(0, 0, canvas.width, canvas.height)//#viewport# tell the rasterizer which part of the canvas to draw to ˙HUN˙ a raszterizáló ide rajzoljon
    camera.setAspectRatio(canvas.width.toFloat()/canvas.height)
  }

  val timeAtFirstFrame = Date().getTime()
  var timeAtLastFrame =  timeAtFirstFrame

  init{
    //LABTODO: enable depth test
    gl.enable(GL.DEPTH_TEST)
    addComponentsAndGatherUniforms(*Program.all)
  }

 

  @Suppress("UNUSED_PARAMETER")
  fun update(keysPressed : Set<String>) {
    val timeAtThisFrame = Date().getTime() 
    val dt = (timeAtThisFrame - timeAtLastFrame).toFloat() / 1000.0f
    val t = (timeAtThisFrame - timeAtFirstFrame).toFloat() / 1000.0f
    timeAtLastFrame = timeAtThisFrame

    //LABTODO: move camera
    camera.move(dt, keysPressed)

    if("Z" in keysPressed) {
      shootArrow(Vec3(0.0f, 3.0f, 0.0f))
    }
    
    gl.clearColor(0.3f, 0.0f, 0.3f, 1.0f)//## red, green, blue, alpha in [0, 1]
    gl.clearDepth(1.0f)//## will be useful in 3D ˙HUN˙ 3D-ben lesz hasznos
    gl.clear(GL.COLOR_BUFFER_BIT or GL.DEPTH_BUFFER_BIT)//#or# bitwise OR of flags

    gl.enable(GL.BLEND)
    gl.blendFunc(
      GL.SRC_ALPHA,
      GL.ONE_MINUS_SRC_ALPHA)

    backgroundMesh.draw(camera)

    gameObjects.forEach{ it.move(dt, t, keysPressed, gameObjects) }


    gameObjects.forEach {
      if(it.shadow) {
        it.using(shadowMaterial).draw(this, this.camera)
      }
    }
    gameObjects.forEach{ it.update() }
    gameObjects.forEach{ it.draw(this, camera) }

    arrowObjects.forEach{it.move(dt, t, keysPressed, gameObjects)}
    arrowObjects.forEach{ it.update() }
    arrowObjects.forEach{ it.draw( this, camera ) }
  }


  fun shootArrow(force : Vec3) {
    val arrow = GameObject(*arrowMeshes)
    arrowObjects += arrow
    arrow.apply{
      shadow = true
      position.set(camera.position)
      scale.set(0.5f,0.5f,0.5f)
      var acceleration = force * invMass * -9.8f
      val drag = 9.8f 
      var aheadVec = camera.ahead * 30f
      velocity.set(aheadVec)
      velocity.y += 2.0f
      move = object : GameObject.Motion(){
        override operator fun invoke(dt : Float, t : Float,
            keysPressed : Set<String>, gameObjects : List<GameObject>):Boolean {
            if((position - avatar1.position).length() > 6.3f 
              && (position - avatar2.position).length() > 5.3f 
              && (position - avatar3.position).length() > 5.3f
              && position.y >= 0.0f) {
                velocity += acceleration * dt
                velocity.y *= exp(-dt * drag/mass)
                position += velocity * dt * 5f
            }
          return true
        }
      }
    }  
  }

}
